local NAME = "Smod"
local Author = "WindSearched"
local BiliLINK = "https://space.bilibili.com/1611824177"

Smod = {}

function Smod.OnLoad()
    Log(NAME,"Load mod "..NAME.." create by "..Author);
    dLog("Load mod"..NAME.."create by"..Author);

    AddChunkGenerator(function(chunk)
        local bodynum = RandomInt(1, 16, 0)
        for i = 1, bodynum do
            local bodystate = {}
            bodystate.location = LocNew(
                RandomFlt(6,16,0),
                RandomFlt(1,16,0),
                RandomFlt(8,16,0),
                RandomFlt(3,16,0),
                RandomFlt(2,16,0),
                RandomFlt(7,16,0)
            )
            bodystate.index = GetNewBodyIndex()
            chunk.bodies:Add(bodystate)

            local structstate = {
                type = SMTypeNew("meteorite", NAME),
                bodyIndex = bodystate.index,
                isStruct = true,
                location = LocNew(
                    RandomFlt(10,16,0),
                    RandomFlt(5,16,0),
                    RandomFlt(8,16,0),
                    RandomFlt(3,16,0),
                    RandomFlt(2,16,0),
                    RandomFlt(9,16,0)
                ),
                temperature = RandomFlt(273, 500, 0),
                mass = RandomFlt(100, 10, 0)
            }
            chunk.structs:Add(structstate)

            end

        end)
end
function Smod.OnExit()
    Log(NAME,"Detected the game exit, thanks for playing")
end
function Smod.wwwwww()
    Log(NAME,"wedfdsqwedfdswerfsdfgv")
end

Register(NAME,Smod)